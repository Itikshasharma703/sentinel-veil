# Sentinel Veil — Defensive Perimeter Safety System

> **Status:** concept + software showcase prototype. This document is intentionally suitable for early review, not a deployment instruction set.

## 1. Executive summary

Difficult border and perimeter environments create a staffing problem: terrain, distance, darkness, weather, communications, and fatigue make constant visual observation expensive and unreliable. Sentinel Veil proposes a **layered, human-supervised sensing system** that helps an authorized operator decide whether an event deserves attention.

The central design rule is simple:

> **A signal is not a threat. An alert is not a verdict.**

A compliant optical/laser-adjacent sensor can indicate that something crossed a monitored zone, but it should never be the sole trigger for a consequential response. The software combines independent evidence—such as thermal/visible imagery, passive radar or time-of-flight context, environmental telemetry, and short-term temporal consistency—before it presents a clear review card to a human operator.

This concept is deliberately non-weaponized. It does not provide autonomous engagement, weapon guidance, identity surveillance, face recognition, harmful laser use, or instructions for covert deployment.

## 2. Problem framing

### Desired outcomes

1. Detect meaningful perimeter events earlier than a single camera or a fatigued patrol can.
2. Reduce false alarms from animals, moving vegetation, rain, dust, insects, glare, and transient reflections.
3. Continue producing useful evidence when one sensor is degraded by fog, darkness, vibration, or communications loss.
4. Make the reason for every alert visible: which sensors agreed, which quality checks passed, and what remains uncertain.
5. Preserve human control, privacy, auditability, and legal compliance.

### Non-goals

- No automated use of force or physical interdiction.
- No face recognition, biometric identification, watchlists, or persistent person tracking.
- No high-power or harmful laser design; future optical work must use certified eye-safe components and independent safety review.
- No “scan a person and infer intent” capability. The system may only surface observable, uncertainty-aware cues for an authorized reviewer.
- No site-specific deployment plan, coordinates, beam geometry, or sensitive operating envelope in public materials.

## 3. Proposed system architecture

```text
[Passive / optical trigger]
          |
          v
[Edge quality gate] -- rejects saturation, occlusion, drift, low confidence
          |
          v
[Sensor correlation] -- time window + spatial consistency + environmental context
          |
          v
[AI classification] -- animal / human-like / unknown / artifact
          |
          v
[Secondary non-invasive screening]
          |
          v
[Human review card] -- evidence, confidence, uncertainty, recommended next safe step
          |
          v
[Audit + retention policy] -- resolve / escalate to authorized process / close
```

### Sensor roles

| Layer | Example role | What it can prove | What it cannot prove |
| --- | --- | --- | --- |
| Optical or break-beam input | Detects a change in a defined line/zone | A signal changed at a time and location estimate | That a person or threat caused it |
| Visible + thermal camera | Supplies contextual imagery across lighting conditions | Shape, motion, heat pattern, scene quality | Identity or intent |
| Passive radar / time-of-flight context | Adds motion and range consistency | Movement exists and whether it is coherent over time | Malicious intent |
| Weather and health telemetry | Explains degraded evidence | Fog, rain, dust, vibration, temperature, link health | The event classification itself |
| Operator review | Makes the consequential decision | Whether the evidence is sufficient for the next lawful step | Perfect certainty |

A future prototype should select sensors based on terrain, civil aviation/optical safety constraints, local law, maintainability, and total lifecycle cost—not on maximum range alone.

## 4. False-alarm reduction strategy

### A. Quality gates before AI

Before classification, reject or downgrade evidence with lens occlusion, overexposure, unstable alignment, heavy fog, signal saturation, out-of-date calibration, or a broken time reference. A degraded sensor should be visible to the operator instead of silently producing confident-looking output.

### B. Multi-sensor agreement

Require agreement across independent modalities where possible. For example, a short optical interruption plus a thermal silhouette and consistent motion over several frames is stronger than any one cue. Correlation should use conservative time windows and show missing inputs rather than filling gaps with imagined certainty.

### C. Temporal persistence

One frame is not enough. Use a short sequence to distinguish an animal, branch movement, vehicle reflection, person-like motion, and sensor artifact. The exact timing is a test parameter, not a universal constant; it must be selected from measured site data.

### D. Environmental context

Feed weather, visibility, vibration, sun angle, and device health into a **quality score**, not directly into a threat score. When conditions are poor, the system should say “evidence degraded” and request human review, not increase alarm confidence.

### E. Classifier abstention

The model must be able to say `unknown` or `insufficient evidence`. This is a core safety feature. A high-confidence animal classification can close an event only when the evidence quality is good and policy permits; otherwise it routes to review.

### F. Human-readable reason codes

Every alert should expose reason codes such as `OPTICAL_BREAK`, `THERMAL_MATCH`, `LOW_VISIBILITY`, `ANIMAL_LIKELY`, `SENSOR_DISAGREEMENT`, or `HUMAN_REVIEW_REQUIRED`. Do not show a single opaque percentage as if it were a verdict.

## 5. Weather, terrain, and distance challenges

| Challenge | Failure mode | Mitigation direction | Acceptance evidence |
| --- | --- | --- | --- |
| Fog / rain / dust | Contrast loss, false optical interruptions | Sensor diversity, visibility health gate, thermal fallback, conservative abstention | Measured precision/recall by weather bucket |
| Snow / heat shimmer | Misalignment and apparent motion | Mechanical reference points, periodic calibration, thermal quality checks | Drift and calibration logs |
| Uneven terrain | Occlusion and dead zones | Coverage survey, overlapping views, explicit coverage map | Independent coverage review |
| Long distances | Small targets, latency, link loss | Edge processing, store-and-forward evidence, segmented zones | End-to-end alert latency distribution |
| Night conditions | Visible camera weakness | Thermal + low-light pairing, controlled illumination only where lawful and safe | Night test set with unknown class |
| Vegetation / wildlife | Repeated nuisance events | Site-specific negative dataset, temporal motion features, wildlife-aware zones | False alarm rate per hour and season |
| Power interruptions | Sensor and network gaps | Local UPS/solar feasibility, health alerts, graceful degradation | Recovery time and missing-data visibility |
| Communications outage | Central view disappears | Edge queue, local audit buffer, delayed sync with integrity checks | No silent data loss under test |
| Maintenance drift | Confidence slowly degrades | Self-test, lens/align health, calibration schedule, spare strategy | Preventive-maintenance compliance |

**Important:** “high beam” is not a general solution. Increasing optical power can create eye, aviation, wildlife, and legal risks while still failing in fog or dust. Use compliant, eye-safe sensing and treat distance as a systems-engineering problem across optics, coverage, edge compute, power, and communications.

## 6. AI/data pipeline

### Collection principles

- Start with synthetic and consented, staged data before any field collection.
- Label `animal`, `human-like`, `vehicle-like`, `vegetation`, `weather artifact`, `sensor artifact`, and `unknown` with uncertainty.
- Record sensor health and environmental context beside each clip.
- Separate training, validation, and holdout sites so that performance is not inflated by memorizing one background.
- Strip or blur unnecessary personal information; define retention before collecting.

### Inference flow

1. Edge device timestamps and validates input integrity.
2. Quality gate assigns evidence-health flags.
3. A fusion layer aligns modalities without inventing missing data.
4. Classifier returns class distribution plus abstention state and reason codes.
5. Policy engine applies conservative thresholds and routes to human review.
6. Operator action is logged with the evidence shown at the time.

### Model governance

- Version every model and threshold configuration.
- Keep a rollback path and a “model unavailable” mode.
- Evaluate per weather condition, camera type, terrain class, lighting, wildlife category, and camera angle.
- Test for systematic under-detection or over-alerting in the environments where the system will be used.
- Never convert a model score into intent, guilt, or identity.

## 7. Privacy, cybersecurity, and governance

### Privacy

Use purpose limitation, least collection, short default retention, strict role-based access, redaction, audit logs, and documented deletion. Prefer event clips over continuous recording where appropriate. Do not build a biometric database as a shortcut to classification.

### Cybersecurity

- Secure boot and signed firmware where hardware permits.
- Unique device identities; no shared default passwords.
- Mutual authentication between edge nodes and the review service.
- Encrypt data in transit and at rest.
- Network segmentation, minimal ports, rate limiting, and offline-safe behavior.
- Tamper-evident audit logs with clock-health monitoring.
- Threat model spoofed optical signals, replayed clips, sensor blinding, model poisoning, stolen devices, and operator-account compromise.

### Human factors

Alert cards must show confidence and uncertainty together. Use clear states: `observing`, `evidence degraded`, `review required`, `cleared`, and `service needed`. Avoid flashing red UI, alarm fatigue, or language that presumes intent. Train operators on abstention and escalation policy.

### Legal and safety review

Before any pilot, obtain jurisdiction-specific review covering privacy/data protection, border or restricted-area rules, aviation/optical safety, worker safety, radio/spectrum constraints, procurement, records retention, and accessibility. An independent safety lead should be able to stop the pilot.

## 8. Prototype plan

### Phase 0 — paper and simulation

- Freeze the non-weaponized scope.
- Build a small event simulator with wildlife, human-review, weather-degraded, and sensor-artifact scenarios.
- Define metrics and reason codes before selecting hardware.

### Phase 1 — benchtop sensor rig

- Use commercially available, certified, eye-safe sensors.
- Exercise optical input, camera, environmental telemetry, local compute, and event logging on a table or indoor test lane.
- No real perimeter deployment and no automated actuation.

### Phase 2 — controlled outdoor test

- Use a permissioned, clearly marked site with staged movement and consent.
- Measure weather buckets, nuisance-event rate, evidence health, latency, power, and link resilience.
- Independent observer validates that the operator sees the same evidence the system used.

### Phase 3 — shadow mode

- Run beside an existing authorized process without changing decisions.
- Compare alerts with ground truth and human workload.
- Keep fail-safe behavior and manual shutdown visible.

### Phase 4 — limited pilot review

- Only after safety, privacy, cyber, legal, and performance gates pass.
- Define stop conditions, incident reporting, maintenance ownership, and a rollback plan.
- Reassess whether the technology is appropriate at all; “do not deploy” is a valid outcome.

## 9. Metrics and test gates

Track precision, recall, false alarms per hour, unknown/abstention rate, missed-event rate, alert latency, operator review time, sensor availability, degraded-evidence rate, power autonomy, data-loss rate, and cybersecurity events. Report confidence intervals and performance by environmental bucket; never advertise one best-case range number.

Suggested gates for a prototype review:

- No autonomous actuation path exists in hardware or software.
- Every alert has a reason code, sensor health, and audit record.
- The system can enter a safe degraded mode and tell the operator why.
- The classifier can abstain and does not require identity recognition.
- Privacy, legal, optical safety, and cyber reviews are documented.
- A human can disable sensing and erase or quarantine collected test data.

## 10. Recommended next decision

Treat Sentinel Veil as a **safety engineering and evidence-quality project**, not a “maximum range” project. Start with the simulator and a permissioned, non-operational benchtop rig. Pick hardware only after a requirements workshop that includes a safety officer, privacy counsel, cybersecurity engineer, field operator, and an independent test lead.
