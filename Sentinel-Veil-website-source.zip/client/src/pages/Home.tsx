import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  BadgeCheck,
  Camera,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleAlert,
  CloudFog,
  Eye,
  FileText,
  GitBranch,
  Info,
  LockKeyhole,
  Menu,
  Network,
  Radar,
  Radio,
  ScanLine,
  ShieldCheck,
  Sparkles,
  ThermometerSnowflake,
  UserRoundCheck,
  Waves,
  X,
  Zap,
} from "lucide-react";

type Scenario = "wildlife" | "human";
type DemoStep = "idle" | "observe" | "correlate" | "classify" | "review" | "cleared";

const steps = [
  {
    key: "observe",
    number: "01",
    title: "Observe",
    copy: "A change is logged, never treated as intent.",
    icon: ScanLine,
  },
  {
    key: "correlate",
    number: "02",
    title: "Correlate",
    copy: "Independent inputs test whether the signal persists.",
    icon: Network,
  },
  {
    key: "classify",
    number: "03",
    title: "Classify",
    copy: "The model can say animal, artifact, human-like, or unknown.",
    icon: Sparkles,
  },
  {
    key: "review",
    number: "04",
    title: "Review",
    copy: "A person decides whether any safe next step is warranted.",
    icon: UserRoundCheck,
  },
] as const;

const challenges = [
  {
    icon: CloudFog,
    label: "WEATHER",
    title: "Fog should lower confidence, not raise alarm.",
    copy: "Visibility, lens health, rain, dust, and heat shimmer become evidence-quality flags. If the scene is degraded, the system abstains and says why.",
    accent: "mint",
  },
  {
    icon: Waves,
    label: "TERRAIN",
    title: "Coverage is a design constraint.",
    copy: "Ridges, vegetation, dead zones, and changing sight lines require a coverage survey, overlapping views, and honest gaps in the evidence.",
    accent: "yellow",
  },
  {
    icon: Radar,
    label: "DISTANCE",
    title: "Range is a systems problem, not a beam problem.",
    copy: "Edge processing, segmented zones, power resilience, and store-and-forward evidence matter more than simply increasing optical power.",
    accent: "blue",
  },
  {
    icon: LockKeyhole,
    label: "TRUST",
    title: "Privacy and cyber controls are part of detection.",
    copy: "Least collection, short retention, signed firmware, device identity, encryption, and tamper-evident logs protect the people around the system.",
    accent: "coral",
  },
];

const phases = [
  ["00", "Simulate", "Synthetic events, abstention logic, reason codes, and stop conditions."],
  ["01", "Bench", "Certified eye-safe sensors on a table; no field deployment or actuation."],
  ["02", "Validate", "Permissioned outdoor tests, staged movement, weather buckets, and independent observation."],
  ["03", "Shadow", "Run beside an authorized process without changing decisions; measure workload and misses."],
  ["04", "Review", "Only after safety, privacy, cyber, legal, and performance gates pass."],
];

const sensorCards = [
  ["01", "Optical change", "A line or zone changed", "Not a person. Not intent."],
  ["02", "Context camera", "Shape, motion, heat pattern", "Not identity."],
  ["03", "Health telemetry", "Weather and device quality", "Not threat level."],
  ["04", "Human review", "Evidence is sufficient", "Not automatic action."],
];

function useReveal() {
  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>("[data-reveal]");
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => entry.isIntersecting && entry.target.classList.add("is-visible")),
      { threshold: 0.12 },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);
}

function DemoConsole() {
  const [scenario, setScenario] = useState<Scenario>("wildlife");
  const [stepIndex, setStepIndex] = useState(0);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const demoSteps: DemoStep[] = ["observe", "correlate", "classify", "review"];

  useEffect(() => {
    if (!running) return;
    if (stepIndex >= demoSteps.length) {
      setRunning(false);
      setDone(true);
      return;
    }
    const timer = window.setTimeout(() => setStepIndex((current) => current + 1), 820);
    return () => window.clearTimeout(timer);
  }, [running, stepIndex]);

  const currentStep = stepIndex === 0 ? "idle" : stepIndex >= demoSteps.length ? (scenario === "wildlife" ? "cleared" : "review") : demoSteps[stepIndex - 1];
  const confidence = scenario === "wildlife" ? "animal-like / 92" : "human-like / 68";
  const outcome = scenario === "wildlife" ? "CLEAR AFTER REVIEW" : "HUMAN REVIEW REQUIRED";

  const run = () => {
    setStepIndex(0);
    setDone(false);
    setRunning(true);
    window.setTimeout(() => setStepIndex(1), 120);
  };

  return (
    <div className="demo-shell">
      <div className="demo-topline">
        <div>
          <span className="mono-label">CONCEPT CONSOLE / ILLUSTRATIVE ONLY</span>
          <h3>Try the trust gate</h3>
        </div>
        <div className="live-chip"><span className="live-dot" /> NO HARDWARE LINK</div>
      </div>
      <div className="demo-scenario-row">
        <button className={`scenario-button ${scenario === "wildlife" ? "selected" : ""}`} onClick={() => { setScenario("wildlife"); setDone(false); setStepIndex(0); }}>
          <span className="scenario-icon"><Waves size={16} /></span>
          <span><strong>Wildlife-like event</strong><small>Expected nuisance signal</small></span>
          {scenario === "wildlife" && <Check size={16} />}
        </button>
        <button className={`scenario-button ${scenario === "human" ? "selected" : ""}`} onClick={() => { setScenario("human"); setDone(false); setStepIndex(0); }}>
          <span className="scenario-icon warm"><UserRoundCheck size={16} /></span>
          <span><strong>Human-like event</strong><small>Needs authorized review</small></span>
          {scenario === "human" && <Check size={16} />}
        </button>
      </div>
      <div className="demo-console-grid">
        <div className="console-visual">
          <div className="scan-orbit orbit-one" />
          <div className="scan-orbit orbit-two" />
          <div className="console-target"><Radio size={20} /><span>{scenario === "wildlife" ? "MOTION" : "MOTION + HEAT"}</span></div>
          <div className="console-readout"><span>EVENT / SV-042</span><strong>{currentStep === "idle" ? "STANDBY" : currentStep.toUpperCase()}</strong></div>
        </div>
        <div className="console-evidence">
          <div className="evidence-row"><span>OPTICAL INPUT</span><b className={stepIndex >= 1 ? "good" : "pending"}>{stepIndex >= 1 ? "CAPTURED" : "WAITING"}</b></div>
          <div className="evidence-row"><span>CONTEXT CAMERA</span><b className={stepIndex >= 2 ? "good" : "pending"}>{stepIndex >= 2 ? "CORRELATED" : "WAITING"}</b></div>
          <div className="evidence-row"><span>CLASSIFIER</span><b className={stepIndex >= 3 ? "good" : "pending"}>{stepIndex >= 3 ? confidence : "WAITING"}</b></div>
          <div className="evidence-row"><span>POLICY GATE</span><b className={stepIndex >= 4 ? (scenario === "wildlife" ? "good" : "warm-text") : "pending"}>{stepIndex >= 4 ? outcome : "WAITING"}</b></div>
          <button className="run-button" disabled={running} onClick={run}>{running ? "RUNNING SEQUENCE…" : done ? "RUN AGAIN" : "RUN ILLUSTRATIVE EVENT"}<ArrowRight size={16} /></button>
        </div>
      </div>
      <div className={`demo-result ${done ? "visible" : ""} ${scenario === "human" ? "review-result" : ""}`}>
        {scenario === "wildlife" ? <CheckCircle2 size={18} /> : <CircleAlert size={18} />}
        <span><strong>{done ? outcome : "Outcome waits for all evidence"}</strong>{done && (scenario === "wildlife" ? " — no automatic response." : " — no identity inference, no automatic response.")}</span>
      </div>
    </div>
  );
}

function Home() {
  useReveal();
  const [menuOpen, setMenuOpen] = useState(false);
  const year = useMemo(() => new Date().getFullYear(), []);

  return (
    <main className="site-shell">
      <nav className="site-nav">
        <a href="#top" className="brand" onClick={() => setMenuOpen(false)}>
          <span className="brand-mark"><span /></span>
          <span><strong>Sentinel Veil</strong><small>AI PERIMETER SAFETY</small></span>
        </a>
        <button className="mobile-menu" aria-label="Toggle navigation" onClick={() => setMenuOpen((open) => !open)}>{menuOpen ? <X size={20} /> : <Menu size={20} />}</button>
        <div className={`nav-links ${menuOpen ? "open" : ""}`}>
          <a href="#system" onClick={() => setMenuOpen(false)}>System</a>
          <a href="#signals" onClick={() => setMenuOpen(false)}>Signals</a>
          <a href="#roadmap" onClick={() => setMenuOpen(false)}>Roadmap</a>
          <a href="#guardrails" onClick={() => setMenuOpen(false)}>Guardrails</a>
          <a href="#brief" className="nav-cta" onClick={() => setMenuOpen(false)}>Read the brief <ArrowUpRightIcon /></a>
        </div>
        <div className="private-state"><LockKeyhole size={13} /> PRIVATE PREVIEW</div>
      </nav>

      <section className="hero section-pad" id="top">
        <div className="hero-grid">
          <div className="hero-copy" data-reveal>
            <div className="eyebrow"><span className="eyebrow-line" /> FIELD NOTE 001 / EVIDENCE-LED SAFETY</div>
            <h1>See the signal.<br /><em>Prove the threat.</em><br />Escalate only when warranted.</h1>
            <p className="hero-lede">A calmer approach to difficult perimeters: combine independent sensors, expose uncertainty, and keep every consequential decision in human hands.</p>
            <div className="hero-actions"><a className="primary-button" href="#system">Explore the system <ArrowRight size={17} /></a><a className="text-link" href="#guardrails">Read the safety boundary <ArrowDownRight size={16} /></a></div>
            <div className="hero-note"><ShieldCheck size={18} /><span><strong>Non-weaponized by design.</strong> No autonomous response, harmful laser use, or identity surveillance in this concept.</span></div>
          </div>
          <div className="hero-instrument" data-reveal>
            <div className="instrument-heading"><span className="mono-label">SV / FIELD MODEL</span><span className="instrument-status"><span className="live-dot" /> READY FOR REVIEW</span></div>
            <div className="instrument-map">
              <div className="map-grid" />
              <div className="map-horizon" />
              <div className="map-scan scan-a" /><div className="map-scan scan-b" />
              <div className="map-node node-a"><span /><small>OPTICAL</small></div>
              <div className="map-node node-b"><span /><small>THERMAL</small></div>
              <div className="map-node node-c"><span /><small>WEATHER</small></div>
              <div className="map-center"><span className="center-ring"><Radar size={25} /></span><small>HUMAN REVIEW</small></div>
              <div className="map-path path-a" /><div className="map-path path-b" /><div className="map-path path-c" />
              <div className="map-coords"><span>ZONE / A–04</span><span>LINK HEALTH 98.4%</span></div>
            </div>
            <div className="instrument-footer"><span><Activity size={14} /> 04 EVIDENCE LAYERS</span><span><Eye size={14} /> ABSTENTION ENABLED</span></div>
          </div>
        </div>
        <div className="hero-scroll"><span>SCROLL TO TRACE THE SIGNAL</span><span className="scroll-line" /></div>
      </section>

      <section className="stat-strip"><div className="stat-item"><strong>04</strong><span>evidence layers<br />before review</span></div><div className="stat-item"><strong>00</strong><span>autonomous<br />response paths</span></div><div className="stat-item"><strong>01</strong><span>human handoff<br />for every alert</span></div><div className="stat-statement">Built for the moments when the environment is loud, the evidence is partial, and confidence should be earned.</div></section>

      <section className="section-pad section-light" id="system">
        <div className="section-intro" data-reveal><div><div className="eyebrow"><span className="eyebrow-line" /> THE SIGNAL PATH</div><h2>Layered sensing.<br /><em>Visible restraint.</em></h2></div><p>Laser or optical sensing can tell you that something changed. It cannot tell you why. Sentinel Veil treats that first signal as an invitation to gather better evidence—not permission to act.</p></div>
        <div className="signal-path" data-reveal>{steps.map((step, index) => { const Icon = step.icon; return <div className="signal-step" key={step.key}><div className="step-marker"><span>{step.number}</span><Icon size={19} /></div><div className="step-copy"><span className="mono-label">TRUST GATE / {step.number}</span><h3>{step.title}</h3><p>{step.copy}</p></div>{index < steps.length - 1 && <div className="step-connector" />}</div>; })}</div>
        <div className="callout-band" data-reveal><div className="callout-icon"><Info size={19} /></div><p><strong>Design rule:</strong> degraded weather lowers confidence; it never increases alarm confidence. When evidence is weak, the system says <em>unknown</em>.</p><span className="callout-tag">ABSTENTION IS A FEATURE</span></div>
      </section>

      <section className="section-pad section-dark" id="signals"><div className="section-intro light" data-reveal><div><div className="eyebrow"><span className="eyebrow-line" /> PROTOTYPE LOGIC</div><h2>Try the trust<br /><em>gate yourself.</em></h2></div><p>A small, local simulation of the decision discipline. It does not connect to hardware, identify anyone, or trigger any external action.</p></div><div className="demo-wrap" data-reveal><DemoConsole /></div></section>

      <section className="section-pad section-light"><div className="section-intro compact" data-reveal><div><div className="eyebrow"><span className="eyebrow-line" /> FOUR LENSES</div><h2>Every layer has a job.<br /><em>Every job has a limit.</em></h2></div><p>Clarity comes from naming what the sensor can prove—and refusing to pretend it proved more.</p></div><div className="lens-grid" data-reveal>{sensorCards.map(([number, title, can, cannot]) => <div className="lens-card" key={number}><span className="lens-number">{number}</span><div className="lens-icon">{number === "01" ? <ScanLine size={20} /> : number === "02" ? <Camera size={20} /> : number === "03" ? <ThermometerSnowflake size={20} /> : <UserRoundCheck size={20} />}</div><h3>{title}</h3><div className="lens-line"><BadgeCheck size={15} /><span>{can}</span></div><div className="lens-line muted"><X size={15} /><span>{cannot}</span></div></div>)}</div></section>

      <section className="section-pad challenge-section"><div className="section-intro light" data-reveal><div><div className="eyebrow"><span className="eyebrow-line" /> CHALLENGE MAP</div><h2>The environment<br /><em>is part of the model.</em></h2></div><p>No single “high beam” solves fog, terrain, drift, outages, or false positives. Resilience is a portfolio of small, testable choices.</p></div><div className="challenge-grid" data-reveal>{challenges.map(({ icon: Icon, label, title, copy, accent }) => <article className={`challenge-card ${accent}`} key={label}><div className="challenge-icon"><Icon size={19} /></div><span className="mono-label">{label}</span><h3>{title}</h3><p>{copy}</p><a href="#brief">See mitigation notes <ArrowUpRightIcon /></a></article>)}</div></section>

      <section className="section-pad section-light" id="roadmap"><div className="section-intro compact" data-reveal><div><div className="eyebrow"><span className="eyebrow-line" /> BUILD IN THE RIGHT ORDER</div><h2>Prototype the proof<br /><em>before the hardware.</em></h2></div><p>Start with synthetic events and clear stop conditions. Earn the right to test outdoors; never jump from a sketch to an operational deployment.</p></div><div className="roadmap" data-reveal>{phases.map(([num, title, copy], index) => <div className={`roadmap-row ${index === 0 ? "current" : ""}`} key={num}><span className="roadmap-num">{num}</span><div className="roadmap-rail"><span /><i /></div><div className="roadmap-copy"><div><span className="mono-label">PHASE {num} {index === 0 && " / NOW"}</span><h3>{title}</h3></div><p>{copy}</p></div></div>)}</div></section>

      <section className="guardrails-section section-pad" id="guardrails"><div className="guardrail-grid" data-reveal><div><div className="eyebrow light"><span className="eyebrow-line" /> SAFETY BOUNDARY</div><h2>Capability is not<br /><em>permission.</em></h2><p className="guardrail-lede">The most important feature is the one this concept refuses to add. Sentinel Veil is built to help people review evidence, not to automate a consequential decision.</p><a href="#brief" className="outline-button">Read the full governance brief <ArrowRight size={16} /></a></div><div className="boundary-list"><div className="boundary-item in"><CheckCircle2 size={20} /><div><span className="mono-label">IN SCOPE</span><h3>Evidence quality</h3><p>Sensor health, weather-aware confidence, explainable reason codes, audit trails, and human review.</p></div></div><div className="boundary-item in"><CheckCircle2 size={20} /><div><span className="mono-label">IN SCOPE</span><h3>Safe prototyping</h3><p>Synthetic data, permissioned tests, certified eye-safe sensing, independent validation, and stop conditions.</p></div></div><div className="boundary-item out"><X size={20} /><div><span className="mono-label">OUT OF SCOPE</span><h3>Autonomous action</h3><p>No weapon control, harmful laser use, identity inference, biometric watchlists, or covert mass surveillance.</p></div></div></div></div></section>

      <section className="section-pad section-light brief-section" id="brief"><div className="brief-card" data-reveal><div className="brief-icon"><FileText size={25} /></div><div><span className="mono-label">THE TECHNICAL BRIEF / VERSION 0.1</span><h2>A full report for the next conversation.</h2><p>Requirements, architecture, weather and terrain challenges, false-alarm reduction, AI/data governance, privacy, cybersecurity, metrics, and a staged prototype plan—kept intentionally above sensitive operational detail.</p></div><div className="brief-actions"><a href="#top" className="primary-button">Back to top <ArrowRight size={16} /></a><span className="brief-note"><LockKeyhole size={14} /> Private preview / no auto-publish</span></div></div></section>

      <footer className="site-footer"><div className="footer-brand"><span className="brand-mark"><span /></span><div><strong>Sentinel Veil</strong><small>AI PERIMETER SAFETY</small></div></div><div className="footer-note">Built to prove the signal.<br />Designed to protect the human decision.</div><div className="footer-meta"><span>CONCEPT / {year}</span><span>NO OPERATIONAL DATA</span><span>HUMAN REVIEW REQUIRED</span></div></footer>
    </main>
  );
}

function ArrowUpRightIcon() {
  return <ArrowRight size={14} style={{ transform: "rotate(-45deg)" }} />;
}

export default Home;
